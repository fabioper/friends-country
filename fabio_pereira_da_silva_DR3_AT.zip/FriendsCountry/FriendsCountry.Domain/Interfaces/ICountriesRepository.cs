﻿using FriendsCountry.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace FriendsCountry.Domain.Interfaces
{
    public interface ICountriesRepository : IRepository<Country>
    {
    }
}
