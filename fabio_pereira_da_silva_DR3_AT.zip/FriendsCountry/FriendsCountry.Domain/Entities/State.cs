﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FriendsCountry.Domain.Entities
{
    public class State : Entity
    {
        public string FlagUri { get; set; }

        public string Name { get; set; }
    }
}
