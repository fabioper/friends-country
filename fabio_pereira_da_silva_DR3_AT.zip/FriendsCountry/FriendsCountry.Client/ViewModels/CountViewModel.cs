﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FriendsCountry.Client.ViewModels
{
    public class CountViewModel
    {
        public int RegisteredCountries { get; set; }
        public int RegisteredStates { get; set; }
        public int RegisteredFriends { get; set; }
    }
}
